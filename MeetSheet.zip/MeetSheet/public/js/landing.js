const createButton = document.querySelector("#createroom");
const videoCont = document.querySelector(".video-self");
const codeCont = document.querySelector("#roomcode");
const joinBut = document.querySelector("#joinroom");
const mic = document.querySelector("#mic");
const cam = document.querySelector("#webcam");

let micAllowed = 1;
let camAllowed = 1;

let mediaConstraints = { video: true, audio: true };

navigator.mediaDevices.getUserMedia(mediaConstraints).then((localstream) => {
  videoCont.srcObject = localstream;
});

const createroomtext = "Creating Room...";

createButton.addEventListener("click", (e) => {
  e.preventDefault();
  createButton.disabled = true;
  createButton.innerHTML = "Creating Room";
  createButton.classList = "createroom-clicked";

  setInterval(() => {
    if (createButton.innerHTML < createroomtext) {
      createButton.innerHTML = createroomtext.substring(
        0,
        createButton.innerHTML.length + 1
      );
    } else {
      createButton.innerHTML = createroomtext.substring(
        0,
        createButton.innerHTML.length - 3
      );
    }
  }, 500);
  location.href = `/room`;
});

joinBut.addEventListener("click", (e) => {
  e.preventDefault();
  if (codeCont.value.trim() == "") {
    codeCont.classList.add("roomcode-error");
    return;
  }
  const code = codeCont.value;
  location.href = `/room/${code}`;
});

codeCont.addEventListener("change", (e) => {
  e.preventDefault();
  if (codeCont.value.trim() !== "") {
    codeCont.classList.remove("roomcode-error");
    return;
  }
});

cam.addEventListener("click", () => {
  if (camAllowed) {
    camAllowed = 0;
    mediaConstraints = { video: false, audio: micAllowed ? true : false };
    navigator.mediaDevices
      .getUserMedia(mediaConstraints)
      .then((localstream) => {
        videoCont.srcObject = localstream;
      });

    cam.classList = "nodevice";
    cam.innerHTML = `<i class="fas fa-video-slash"></i>`;
  } else {
    camAllowed = 1;
    mediaConstraints = { video: true, audio: micAllowed ? true : false };
    navigator.mediaDevices
      .getUserMedia(mediaConstraints)
      .then((localstream) => {
        videoCont.srcObject = localstream;
      });

    cam.classList = "device";
    cam.innerHTML = `<i class="fas fa-video"></i>`;
  }
});

mic.addEventListener("click", () => {
  if (micAllowed) {
    micAllowed = 0;
    mediaConstraints = { video: camAllowed ? true : false, audio: false };
    navigator.mediaDevices
      .getUserMedia(mediaConstraints)
      .then((localstream) => {
        videoCont.srcObject = localstream;
      });

    mic.classList = "nodevice";
    mic.innerHTML = `<i class="fas fa-microphone-slash"></i>`;
  } else {
    micAllowed = 1;
    mediaConstraints = { video: camAllowed ? true : false, audio: true };
    navigator.mediaDevices
      .getUserMedia(mediaConstraints)
      .then((localstream) => {
        videoCont.srcObject = localstream;
      });

    mic.innerHTML = `<i class="fas fa-microphone"></i>`;
    mic.classList = "device";
  }
});
