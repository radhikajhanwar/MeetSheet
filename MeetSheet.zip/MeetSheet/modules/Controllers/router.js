const path = require("path");
const { v4: uuidv4 } = require("uuid");
const serveLoginPage = function (req, res) {
  res.sendFile(path.resolve("public/html/login/login.html"));
};

const serveRegisterPage = function (req, res) {
  res.sendFile(path.resolve("public/html/register/register.html"));
};

const serveIndexPage = (req, res) => {
  res.sendFile(path.resolve("public/html/index.html"));
};

const serveRoomPage = (req, res) => {
  res.sendFile(path.resolve("public/html/room.html"));
};
const createRoom = (req, res) => {
  return res.redirect(`/room/${uuidv4().split("-").join("")}`);
};

module.exports = {
  serveLoginPage,
  serveRegisterPage,
  serveIndexPage,
  createRoom,
  serveRoomPage,
};
