const User = require("../../Models/users/UserModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const registerUser = async (req, res) => {
  try {
    const { fname, lname, email, password } = req.body;

    const name = `${fname.trim().charAt(0).toUpperCase()}${fname.slice(
      1
    )} ${lname.trim().charAt(0).toUpperCase()}${lname.slice(1)}`;

    const user = new User({
      name,
      email,
      password,
    });

    const savedUser = await user.save();
    const { password: savedPassword, ...userData } = savedUser.toObject();
    res.status(200).send(userData);
  } catch (err) {
    res.status(501).send(`something is wrong ${err}`);
  }
};

const loginUser = async function (req, res) {
  const { email, password } = req.body;

  // Find the user by email
  const user = await User.findOne({ email });

  if (!user) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  // Validate the password
  const validPassword = await bcrypt.compare(password, user.password);
  console.log(validPassword);
  if (!validPassword) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  // Create a JWT token
  const token = jwt.sign(
    { userId: user._id, username: user.name },
    process.env.JWT_SECRET,
    {
      expiresIn: "1d",
    }
  );

  // Return the token and user data
  const expiryDate = new Date(Date.now() + 86400000);

  res.cookie("jwtToken", token, {
    expires: expiryDate,
    httpOnly: true,
    secure: true,
  });

  return res.json({
    _id: user._id,
    email: user.email,
  });
};
module.exports = { registerUser, loginUser };
