const jwt = require("jsonwebtoken");

function authenticate(req, res, next) {
  // Get the token from the cookie
  const token = req.cookies.jwtToken;
  if (!token) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    // Verify the token using the secret key
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Save the decoded user to the request object
    req.user = decoded;

    // Call the next middleware
    next();
  } catch (err) {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

module.exports = authenticate;
