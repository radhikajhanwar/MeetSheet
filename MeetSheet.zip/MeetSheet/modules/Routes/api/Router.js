const express = require("express");
const {
  registerUser,
  loginUser,
} = require("../../Controllers/userregisteration");
const Router = express.Router();

Router.post("/register", registerUser);
Router.post("/login", loginUser);

module.exports = Router;
