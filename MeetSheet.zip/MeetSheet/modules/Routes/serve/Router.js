const express = require("express");
const {
  serveLoginPage,
  serveIndexPage,
  createRoom,
  serveRoomPage,
  serveRegisterPage,
} = require("../../Controllers/router");
const authenticate = require("../../auth/authenticate");

const Router = express.Router();
Router.route("/").get(authenticate, serveIndexPage);
Router.route("/room").get(authenticate, createRoom);
Router.route("/room/:room_id").get(authenticate, serveRoomPage);
Router.route("/login").get(serveLoginPage);
Router.route("/register").get(serveRegisterPage);

module.exports = Router;
